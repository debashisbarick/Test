<?php
/**
 * @file
 * Contains \Drupal\resume\Plugin\Block\ResumeBlock.
 */

namespace Drupal\resume\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;

/**
 * Provides a 'resume' block.
 *
 * @Block(
 *   id = "resume_block",
 *   admin_label = @Translation("Resume block"),
 *   category = @Translation("Custom resume block example")
 * )
 */
class ResumeBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {

    $form = \Drupal::formBuilder()->getForm('Drupal\resume\Form\ResumeForm');

    return $form;
   }
}